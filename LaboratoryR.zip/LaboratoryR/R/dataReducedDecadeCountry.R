dataReducedDecadeCountry <- function(decades, countri)
{
  library(dplyr)
  library(tidyr)
  # The first step is the creation of a dataframe to bring all data of increasing emissions
  dfPercDecade <- data.frame(
    country = character(),
    co2_increase = numeric(),
    methane_increase = numeric(),
    nitrous_increase = numeric()
  )
  # Then, creating the new column in the main dataset bringing information about decade
  startYear <- min(Greenhouse_Gas_Emissions$year)
  Greenhouse_Gas_Emissions$decade <- with(Greenhouse_Gas_Emissions, floor((Greenhouse_Gas_Emissions$year - startYear)/10))
  maxDecade <- max(Greenhouse_Gas_Emissions$decade)
  decadeSelection <- subset(Greenhouse_Gas_Emissions, decade > maxDecade - decades -1 & decade < maxDecade)
  # Only the selection of the columns interested: emissions of co2, methane and nitrous_oxide
  decadeReducedCol <- select(decadeSelection,1,80,8,44,46)
  # Groupby by country and decade and only calculating the mean
  groupedBy <- decadeReducedCol %>% group_by(decade, country) %>% summarise_all(.funs = "mean") # Finally, apply the statistical analysis to each variable grouped by
  # Once all the calculations are done, only select those where the country is the one given
  groupedByCountry <- subset(groupedBy, country == countri)
  # The second step is the calculation of the increase percentage
  for (i in 1:length(groupedByCountry))
  {
    co2_ini = as.numeric(groupedByCountry[i,3])
    co2_fin = as.numeric(groupedByCountry[i+1,3])
    co2_perc = ((co2_fin - co2_ini)/co2_ini)*100
    methane_ini = as.numeric(groupedByCountry[i,4])
    methane_fin = as.numeric(groupedByCountry[i+1,4])
    methane_perc = ((methane_fin - methane_ini)/methane_ini)*100
    nitro_ini = as.numeric(groupedByCountry[i,5])
    nitro_fin = as.numeric(groupedByCountry[i+1,5])
    nitro_perc = ((nitro_fin - nitro_ini)/nitro_ini)*100
    # Add the new variables to the created dataframe
    dfPercDecade <- dfPercDecade %>% add_row(country = as.character(groupedByCountry[i,2]), co2_increase = co2_perc, methane_increase = methane_perc, nitrous_increase = nitro_perc)
  }
  return(dfPercDecade)
}