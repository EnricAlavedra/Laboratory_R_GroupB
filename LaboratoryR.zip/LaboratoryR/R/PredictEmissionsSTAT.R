PredictEmissionsSTAT <- function(decades, countries)
{
  decadesMeanFinal<- data.frame(
    decade = numeric(),
    country = character(),
    co2 = numeric(),
    methane = numeric(),
    nitrous_oxide = numeric()
  )
  
  for (i in 1:length(countries))
  {
    countri <- as.character(countries[i])
    decadesMean <- PredictEmissions(decades, countri)
    decadesMeanFinal <- rbind(decadesMeanFinal, decadesMean)
  }
  decadesMeanFinal <- subset(decadesMeanFinal, decade >= decades)
  decadeMeanFinalStat <- decadesMeanFinal %>% group_by(country, decade) %>% summarise_at(.vars = c("co2", "methane", "nitrous_oxide"),
                                                                                         .funs = c("mean"))
  return(decadeMeanFinalStat)
}