EmissionsProgressByCountry <- function(country) {
  countryObs <- summariseTableCountry[which(summariseTableCountry$country == country), ]
  decadeVariationCountry <- countryObs %>% group_by(decade) %>% summarise_at(.vars = c("co2", "methane", "nitrous_oxide"),
                                                                             .funs = c("mean"))
  data <- pivot_longer(
    decadeVariationCountry,
    cols = c("co2", "methane", "nitrous_oxide"),
    names_to = "Variable",
    values_to = "Value"
  )
  finalPlot <- ggplot(data, aes(x = decade, y = Value, color = Variable, linetype = Variable)) +
    geom_line() +
    labs(title = paste("Emissions evolution through decades in ", country))
  return(finalPlot)
}
