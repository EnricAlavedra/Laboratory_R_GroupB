dataframeExportation <- function(decades, statFunc)
{
  library(writexl)
  # The first step is to reduce the dataframe to only consider the observations in the required decades
  dataDecadesReduction <- decadeReduction(decades)
  # The next step is to calculate the demanded statistical metrics for each variable
  statCalculations(dataDecadesReduction, statFunc)
  # Finally, export the data set as an Excel sheet
  write.xlsx(groupedByTable, file = "agg_co2.xlsx")
}