PredictEmissions <- function(decades, countri)
{
  library(dplyr)
  library(tidyr)
  # The first step is to reduce the dataset and prepare it for working: reduce the number of decades to consider and the countries considered. Then, decades have to be indexed from 1 until the maximum
  maxDecade <- max(Greenhouse_Gas_Emissions$decade)
  dataReduction <- subset(Greenhouse_Gas_Emissions, country == countri)
  decadeSelection <- subset(dataReduction, decade > maxDecade - decades -1 & decade < maxDecade)
  decadeReducedCol <- select(decadeSelection,1,80,8,44,46)
  decadeMean <- decadeReducedCol %>% group_by(decade, country) %>% summarise_all(.funs = "sum")
  decadeMean$decade <- with(decadeMean, 1:dim(decadeMean)[1])
  # The second step is to make a linear regression model
  lm_co2 <- lm(co2 ~ decade, data = decadeMean)
  lm_methane <- lm(methane ~ decade, data = decadeMean)
  lm_nitrous_oxide <- lm(nitrous_oxide ~ decade, data = decadeMean)
  # The third step is creating a new row where predictions will be left
  nextDecade <- data.frame(decade = max(decadeMean$decade) + 1)
  # Time for predictions
  newPredictions <- data.frame(
    decade = nextDecade$decade,
    country = countri,
    co2 = predict(lm_co2, newdata = nextDecade),
    methane = predict(lm_methane, newdata = nextDecade),
    nitrous_oxide = predict(lm_nitrous_oxide, newdata = nextDecade)
  )
  decadesMean <- rbind(decadeMean, newPredictions)
  return(decadesMean)
}