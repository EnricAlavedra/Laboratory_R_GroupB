PredictEmissionsALL <- function(decades, countries)
{
  decadesMeanFinal<- data.frame(
    decade = numeric(),
    country = character(),
    co2 = numeric(),
    methane = numeric(),
    nitrous_oxide = numeric()
  )
  
  for (i in 1:length(countries))
  {
    countri <- as.character(countries[i])
    decadesMean <- PredictEmissions(decades, countri)
    decadesMeanFinal <- rbind(decadesMeanFinal, decadesMean)
  }
  return(decadesMeanFinal)
}