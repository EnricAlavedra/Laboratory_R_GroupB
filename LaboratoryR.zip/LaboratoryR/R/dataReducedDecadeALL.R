dataReducedDecadeALL <- function(decades, countries)
{
  dfPerc<- data.frame(
    country = character(),
    co2_increase = numeric(),
    methane_increase = numeric(),
    nitrous_increase = numeric()
  )
  
  for (i in 1:length(countries))
  {
    countri <- countries[i]
    dataReducedCountry <- dataReducedDecadeCountry(decades, countri)
    dfPerc <- rbind(dfPerc, dataReducedCountry)
  }
  return(dfPerc)
}