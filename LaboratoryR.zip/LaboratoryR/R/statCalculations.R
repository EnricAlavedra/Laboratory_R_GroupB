statCalculations <- function(data, statFunc)
{
  library(dplyr)
  library(tidyr)
  summariseTable <- select(data,1, 2, seq(6, length(names(lastDecades)), by = 1))
  summariseTable <- na.omit(summariseTable) # The second step is to remove those observations with NA, as they can bring problems
  groupedByTable <- summariseTable %>% group_by(decade, country) %>% summarise_all(.funs = statFunc)
  return(groupedByTable)
}