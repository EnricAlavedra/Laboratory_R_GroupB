StackedBarPlot <- function(countries, decada)
{
  library(dplyr)
  library(tidyr)
  library(gplots)
  data <- Greenhouse_Gas_Emissions
  dataCountries <- data[data$country %in% countries, ]
  dataDecade <- subset(dataCountries, decade == decada)
  dataReduction <- select(dataDecade,1,8,44,46)
  groupBydata <- dataReduction %>% group_by(country) %>% summarise_all(.funs = "sum")
  dataValues <- as.matrix(groupBydata[, -1])
  paises <- as.vector(groupBydata$country)
  StackedBarPlot <- barplot2(
    dataValues,
    names.arg = paises,
    beside = FALSE,
    legend = colnames(dataValues),
    main = "Total Emissions by Country giving a specific decade",
    xlab = "Country",
    ylab = "Emissions"
  )
  print(StackedBarPlot)
}