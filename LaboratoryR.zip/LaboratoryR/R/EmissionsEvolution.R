EmissionsEvolution <- function(pais)
{
  library(dplyr)
  library(ggplot2)
  library(tidyr)
  countryFiltration <- Greenhouse_Gas_Emissions %>%
    filter(country == pais) %>%
    select(country, year, co2, methane, nitrous_oxide)
  data <- pivot_longer(
    countryFiltration,
    cols = c("co2", "methane", "nitrous_oxide"),
    names_to = "Variable",
    values_to = "Value"
  )
  finalPlot <- ggplot(data, aes(x = year, y = Value, color = Variable, linetype = Variable)) +
    geom_line() +
    labs(title = paste("Emssions evolution for ", pais))
  return(finalPlot)
}