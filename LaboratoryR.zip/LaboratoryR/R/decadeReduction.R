decadeReduction <- function(decades)
{
  library(dplyr)
  startYear <- min(Greenhouse_Gas_Emissions$year)
  Greenhouse_Gas_Emissions$decade <- with(Greenhouse_Gas_Emissions, floor((Greenhouse_Gas_Emissions$year - startYear)/10))
  maxDecade <- max(Greenhouse_Gas_Emissions$decade)
  decadeSelection <- subset(Greenhouse_Gas_Emissions, decade > maxDecade - decades -1 & decade < maxDecade)
}