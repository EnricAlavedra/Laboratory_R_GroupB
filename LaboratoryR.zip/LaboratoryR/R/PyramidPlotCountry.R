PyramidPlotCountry <- function(decades, countri)
{
  library(dplyr)
  library(tidyr)
  library(plotrix)
  # The first step is to reduce the dataset and prepare it for working: reduce the number of decades to consider and the countries considered. Then, decades have to be indexed from 1 until the maximum
  maxDecade <- max(Greenhouse_Gas_Emissions$decade)
  dataReduction <- subset(Greenhouse_Gas_Emissions, country == countri)
  decadeSelection <- subset(dataReduction, decade > maxDecade - decades -1 & decade < maxDecade)
  decadeReducedCol <- select(decadeSelection,1,80,44,46)
  decadeMean <- decadeReducedCol %>% group_by(country, decade) %>% summarise_all(.funs = "sum")
  decadeMean$decade <- with(decadeMean, 1:dim(decadeMean)[1])
  # The second step is to make the pyramid plot and return the plot
  PyramidPlot <- pyramid.plot(decadeMean$methane,decadeMean$nitrous_oxide, decadeMean$decade, main = paste("Methane vs Nitrous Oxide: ", country), top.labels = c("Methane", "Decade", "Nitrous Oxide"), lxcol = "blue", rxcol = "red", unit = "million tonnes", ppmar=c(4,1,4,1), space = 0.3, gap = 1, labelcex = 1)
  print(PyramidPlot)
}